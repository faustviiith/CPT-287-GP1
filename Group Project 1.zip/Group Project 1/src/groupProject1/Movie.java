package groupProject1;

import java.util.Date;

public class Movie {
	String movieName;
	Date releaseDate;
	String description;
	
	//constructor
	public Movie() {
	}
	
	//constructor w/ three arguments
	public Movie(String movieName, Date releaseDate, String description) {
		this.movieName = movieName;
		this.releaseDate = releaseDate;
		this.description = description;
	}

	//Getters and setters
	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public String toString() {
		String movieLine = movieName + " " + releaseDate + " " + description;
		return movieLine;
	}
}