package groupProject1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;


public class GroupProject1 {

	public static void main(String[] args) throws IOException, ParseException {
		FileInputStream inputFile = new FileInputStream("gp1_input.txt");
		Scanner scanner = new Scanner(inputFile);
		FileOutputStream outputFile = new FileOutputStream("output.txt");
		PrintWriter writer = new PrintWriter(outputFile);
		String movieName;
		Date releaseDate;
		String description;

		List<Movie> comingSoon = new ArrayList<Movie>();
		List<Movie> nowPlaying = new ArrayList<Movie>();

		// Reading file and making new movies, adding movies to array list
		//scanner.useDelimiter(" | ");
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Calendar today = Calendar.getInstance();
		today.set(Calendar.HOUR_OF_DAY, 0);
		//LocalDate dateTime = LocalDate.parse.scannernext();
		while (scanner.hasNext()) {
			//movieName = scanner.useDelimiter(" | ").next();
			//releaseDate = formatter.parse(scanner.useDelimiter(" | ").next());
			//description = scanner.nextLine();
			String movieline = scanner.nextLine();
			String movieinfo [] = movieline.split(" \\| ");
			movieName = movieinfo[0];
			releaseDate = formatter.parse(movieinfo[1]);
			description = movieinfo[2];
			
			
			Movie movie1 = new Movie(movieName, releaseDate, description);
			if (releaseDate.after(today.getTime())) {
				comingSoon.add(movie1);
			} else {
				nowPlaying.add(movie1);
			}
		}

		for (Movie movie : comingSoon) {
			System.out.println(movie);
		}
			
		
		// Closing everything
		writer.close();
		outputFile.close();
		scanner.close();
		inputFile.close();
	}

}
